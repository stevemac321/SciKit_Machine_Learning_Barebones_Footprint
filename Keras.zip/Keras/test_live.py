import numpy as np
import tensorflow as tf

# Load model and normalization stats
model = tf.keras.models.load_model("voltage.keras")
stats = np.load("voltage_stats.npz")
mean = stats["mean"]
std = stats["std"]
std[std == 0] = 1.0  # Safety

# Inference function
def infer_row(row_floats):
    x = np.array(row_floats, dtype=np.float32)
    x = (x - mean) / std
    x = x.reshape(1, -1)
    recon = model.predict(x, verbose=0)
    error = np.mean((x - recon)**2)
    return error

# Threshold can be tuned using training data error distribution
#THRESHOLD =  0.051816
THRESHOLD =  2.0



# Read and process file
with open("live.txt", "r") as f:
    for i, line in enumerate(f):
        try:
            floats = list(map(float, line.strip().split()))
            if len(floats) != 128:
                print(f"Row {i}: Invalid length ({len(floats)}), skipped.")
                continue
            error = infer_row(floats)
            status = "ANOMALY" if error > THRESHOLD else "OK"
            print(f"Row {i}: Error={error:.6f}, Status={status}")
        except ValueError:
            print(f"Row {i}: Failed to parse floats, skipped.")
